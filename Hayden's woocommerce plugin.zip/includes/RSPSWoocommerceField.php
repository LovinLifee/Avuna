<?php
add_action( 'woocommerce_checkout_before_customer_details', 'custom_checkout_fields_before_billing_details', 20 );
function custom_checkout_fields_before_billing_details(){
    $domain = 'woocommerce';
    $checkout = WC()->checkout;
    echo '<div id="rsn">';
    echo '<h3>' . __('Custom Fields') . '</h3>';
    woocommerce_form_field( 'rsn', array(
        'type'          => 'text',
        'label'         => __('RSN', $domain ),
        'placeholder'   => __('Please add your RSN here', $domain ),
        'class'         => array('my-field-class form-row-wide'),
        'required'      => true, // or false
    ), $checkout->get_value( 'rsn' ) );
    echo '</div>';
}

add_action( 'woocommerce_checkout_process', 'custom_checkout_field_process' );
function custom_checkout_field_process() {
    if ( isset($_POST['rsn']) && empty($_POST['rsn']) )
        wc_add_notice( __( 'Please enter a valid RSN' ), 'error' );
}

add_action( 'woocommerce_checkout_create_order', 'custom_checkout_field_update_meta', 10, 2 );
function custom_checkout_field_update_meta( $order, $data ){
    if( isset($_POST['rsn']) && ! empty($_POST['rsn']) )
        $order->update_meta_data( 'rsn', sanitize_text_field( $_POST['rsn'] ) );
}
?>