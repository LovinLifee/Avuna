<?php

function get_orders_by_rsn($request) {
	$rsn = $request['rsn'];
	$auto_claim = filter_var($request['autoclaim'], FILTER_VALIDATE_BOOLEAN);
	if (empty($rsn)) {
		return new WP_Error('missing_data', 'Please enter a valid RSN', array('status' => 400));
	}
	$orders = wc_get_orders(array(
		'limit' => -1, // Query all orders
		'orderby' => 'date',
		'order' => 'DESC',
		'meta_key' => 'rsn', // The postmeta key field
		'meta_compare' => 'LIKE', // The comparison argument
		'meta_value' => $rsn,
		'status' => array('wc-processing')
	));
	$unclaimed_orders = array_map(function($order) use (&$auto_claim) {
		if ($auto_claim) {
			$order->update_status('completed');
		}
		return $order->get_data();
	}, $orders);
	$json_response = array('unclaimed_orders' => $unclaimed_orders);
	wp_send_json($json_response);
}

add_action('rest_api_init', function() {
	register_rest_route('wc/v3', 'rsps_orders', array(
		'methods' => 'GET',
		'callback' => 'get_orders_by_rsn',
		'permission_callback' => function($request) {
			return is_user_logged_in() && current_user_can('administrator');
		}
	));
});
?>