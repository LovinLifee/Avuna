<?php
   /*
   Plugin Name: RSPS
   Plugin URI: https://avuna.net
   description: Add woocommerce endpoints for RSPS
   Version: 1.0
   Author: Hayden Taylor
   */
require_once('includes/RSPSWoocommerceEndpoint.php');
require_once('includes/RSPSWoocommerceField.php');
?>
